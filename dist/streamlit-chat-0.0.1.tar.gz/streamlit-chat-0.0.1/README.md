# st-chat

Streamlit Component, for a Chat bot UI
authors - [@yashppawar](https://github.com/yashppawar) & [@YashVardhan-AI](https://github.com/yashvardhan-ai)

### Under Testing Phase, will be released on pypi soon

## Installation

Install `streamlit-chat` with pip
```bash
 pip install streamlit-chat==0.0.1 
```

use
```py
import streamlit as st
from streamlit_chat import message

message("My message")
```
   
